import {type PositionParameter} from './PositionParameter'

export type Position = {
    name : string,
    parameters : PositionParameter[]
} 