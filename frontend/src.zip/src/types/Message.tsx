type Message = {
    id: number;
    chatId: string;
    content: string;
    isSentByUser: boolean;
};
 
