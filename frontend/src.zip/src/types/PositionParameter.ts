export type PositionParameter = {
    title : string;
    description : string;
    point : number;
}

