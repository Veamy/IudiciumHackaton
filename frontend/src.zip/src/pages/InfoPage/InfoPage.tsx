import { useParams } from 'react-router-dom';
import './InfoPageStyle.css'
import NewProfileCreateView from './NewProfileCreateView/NewProfileCreateView';
import NewPositionCreateView from './NewPositionCreateView/NewPositionCreateView';
import LeftBar from './LeftBar/LeftBar'
import type { Position } from '../../types/Position';


export const InfoPage = () => {
  const typeInfo  = useParams().typeInfo ;
  const idInfo = useParams().idInfo ; 

  function ChoiceView(){
    if (typeInfo == "profile") {
      if (idInfo != "create"){
        return( <p>Profile ID</p>);
      }
      return (<NewProfileCreateView />);
    }else if (typeInfo == "position"){
      if (idInfo != "create" ){
        return( <p>Position ID</p>)
      }
      return (
      // <NewPositionCreateView />
      <p>Pivo</p>
      );
    }
    return (<h1>Unknow Error</h1>)

  }

  return (
    <div>

      <LeftBar /> 

      <div className="chat-main-container">
        {ChoiceView()}
      </div>
    </div>
  );
};

export default InfoPage;
