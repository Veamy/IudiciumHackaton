export const ROUTES = {
  HOME: '/',
  INFO: '/info',
  PROFILE: '/profile',
  POSITION: '/position',
  PROFILE_CREATE: '/profile/create',
  POSITION_CREATE: '/position/create',
};
export default ROUTES;