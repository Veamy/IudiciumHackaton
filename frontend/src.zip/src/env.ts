
const API_URL = {
    BACK_END_URL : 'http://localhost:5000/api',
    GET_INFO_ENDPOINT: '/info',
    CREATE_PROFILE_ENDPOINT: '/profile/create',
    GET_PROFILE_ENDPOINT: '/profile/get',
    GET_POSITION_ENDPOINT: '/position/get',
};

export default API_URL ;