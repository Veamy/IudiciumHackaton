
const InputBlock = () => {
  return (
    <div>
        <input placeholder="Type here..." type="text" />
    </div>
  );
};

export default InputBlock;