// src/components/PositionParameterFormView/PositionParameterFormView.tsx
import { type PositionParameter } from '../../types/PositionParameter';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

interface PositionParameterFormViewProps {
  parameter: PositionParameter;
  onChange: (parameter: PositionParameter) => void;
  onRemove: () => void;
  index: number;
}

const PositionParameterFormView: React.FC<PositionParameterFormViewProps> = ({
  parameter: initialParameter,
  onChange,
  onRemove,
  index,
}) => {
  const { t } = useTranslation();

  const [parameter, setParameter] = useState<PositionParameter>(initialParameter);

  // Sync local changes up to parent
  useEffect(() => {
    onChange(parameter);
  }, [parameter, onChange]);

  // Update local state when parent passes a new initial parameter (e.g. on add)
  useEffect(() => {
    setParameter(initialParameter);
  }, [initialParameter]);

  // Helper for namespaced translation keys
  const tp = (key: string) => t(`PositionParameterFormView.parameterForm.${key}`);

  return (
    <div
      style={{
        border: '1px solid #ccc',
        borderRadius: 8,
        padding: 16,
        marginBottom: 16,
        backgroundColor: '#fafafa',
      }}
    >
      <h4>{tp('title')} {index + 1}</h4>

      <div style={{ marginBottom: 12 }}>
        <label>
          {tp('parameterTitle')} <br />
          <input
            type="text"
            value={parameter.title}
            onChange={(e) =>
              setParameter({ ...parameter, title: e.target.value })
            }
            placeholder={tp('parameterTitlePlaceholder')}
            style={{ width: '100%', padding: 8, boxSizing: 'border-box' }}
          />
        </label>
      </div>

      <div style={{ marginBottom: 12 }}>
        <label>
          {tp('description')} <br />
          <textarea
            value={parameter.description}
            onChange={(e) =>
              setParameter({ ...parameter, description: e.target.value })
            }
            rows={3}
            placeholder={tp('descriptionPlaceholder')}
            style={{ width: '100%', padding: 8, boxSizing: 'border-box', resize: 'vertical' }}
          />
        </label>
      </div>

      <div style={{ marginBottom: 16 }}>
        <label>
          {tp('points')} <br />
          <input
            type="number"
            min="0"
            step="1"
            value={parameter.point}
            onChange={(e) =>
              setParameter({
                ...parameter,
                point: e.target.value === '' ? 0 : Number(e.target.value),
              })
            }
            style={{ width: '100%', padding: 8, boxSizing: 'border-box' }}
          />
        </label>
      </div>

      <button
        type="button"
        onClick={onRemove}
        style={{
          background: 'none',
          border: 'none',
          color: '#d32f2f',
          cursor: 'pointer',
          fontSize: '14px',
          padding: 0,
        }}
      >
        {tp('removeButton')}
      </button>
    </div>
  );
};

export default PositionParameterFormView;